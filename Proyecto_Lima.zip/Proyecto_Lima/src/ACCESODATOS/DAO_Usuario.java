package AccesoDatos;
import Configuracion.*;
import java.sql.*;
import Procesos.Mensajes;
import Interfaces.crudUsuario;
import ENTIDADES.Usuario;
public class DAO_Usuario implements crudUsuario {
    @Override
    public void AgregarUs(Usuario us) {
        try{
            Connection con = Conexion.HacerConexion();
            PreparedStatement ps = con.prepareStatement("insert into Usuario(nomape,nomb_usuario,contraseña,correo) values(?,?,?,?);");
            ps.setString(1, us.getNomape());
            ps.setString(2, us.getNomusuario());
            ps.setString(3, us.getContraseña());
            ps.setString(4, us.getCorreo());
            ps.executeUpdate();
            Mensajes.MostrarTexto("Registro insertado correctamente...");
        }catch(Exception ex){
            Mensajes.MostrarTexto("Error no se puede insertar... "+ex);
        } 
    }
    public static Usuario VerificarUsuario(Usuario us){
       Connection con = Conexion.HacerConexion();
       Usuario usuario=null;
       try{
           //El preparedstatement permite parametrizar las consultas
           PreparedStatement ps = con.prepareStatement("select * from Usuario where nomb_usuario=? and contraseña=?;");
           //actualizando la consulta
           ps.setString(1,us.getNomusuario());
           ps.setString(2, us.getContraseña());
           //recuperando los datos
           ResultSet rs = ps.executeQuery();
           //verificamos si hay registros
           if(rs.next()){
               usuario=new Usuario();
               usuario.setId(rs.getInt(1));
               usuario.setNomape(rs.getString(2));
               usuario.setNomusuario(rs.getString(3));
               usuario.setCorreo(rs.getString(4));
               usuario.setContraseña(rs.getString(5));
           }
       }catch(Exception ex){
           Mensajes.MostrarTexto("ERROR al consultar usuario."+ex);
       }
       return usuario;
}
    




}
