
package ACCESODATOS;
import ENTIDADES.Usuario;
import Configuracion.*;
import PROCESOS.ProcesoTarjeta;
import Procesos.Mensajes;
import ENTIDADES.Tarjeta;
import java.sql.*;
import java.util.ArrayList;
public class DAO_Tarjeta {
    public void AgregarTar(Tarjeta tar) {
        try{
            Connection con = Conexion.HacerConexion();
            PreparedStatement ps = con.prepareStatement("insert into Tarjeta(id_usuario,dni,correo,celular,imagen,saldo) values(?,?,?,?,?,0);");
            ps.setInt(1, tar.getId_usuario());
            ps.setString(2, tar.getDni());
            ps.setString(3, tar.getCorreo());
            ps.setString(4, tar.getCelular());
            ps.setBytes(5, tar.getImagen());
            ps.executeUpdate();
            Mensajes.MostrarTexto("Registro insertado correctamente...");
        }catch(Exception ex){
            Mensajes.MostrarTexto("Error no se puede insertar... "+ex);
        } 
    }
    
    public int idUsuario(String nombreusuario) {
    int id = 0;
    try {
        Connection con = Conexion.HacerConexion();
        PreparedStatement ps = con.prepareStatement(
            "SELECT id FROM Usuario WHERE nomape = ?;"
        );
        ps.setString(1, nombreusuario);
        ResultSet rs = ps.executeQuery();
        if (rs.next()) {
            id = rs.getInt(1);
        }
    } catch (Exception ex) {
        Mensajes.MostrarTexto("ERROR al recuperar el stock: " + ex);
    }
    return id;
}
    
    public int idTarjeta(int id) {
    int idtarjeta = 0;
    try {
        Connection con = Conexion.HacerConexion();
        PreparedStatement ps = con.prepareStatement(
            "SELECT idtarjeta FROM Tarjeta WHERE id_usuario = ?;"
        );
        ps.setInt(1, id);
        ResultSet rs = ps.executeQuery();
        if (rs.next()) {
            idtarjeta = rs.getInt(1);
        }
    } catch (Exception ex) {
        Mensajes.MostrarTexto("ERROR al recuperar el stock: " + ex);
    }
    return idtarjeta;
}
    public double saldoTarjeta(int id) {
    double saldo = 0;
    try {
        Connection con = Conexion.HacerConexion();
        PreparedStatement ps = con.prepareStatement(
            "SELECT saldo FROM Tarjeta WHERE idtarjeta = ?;"
        );
        ps.setInt(1, id);
        ResultSet rs = ps.executeQuery();
        if (rs.next()) {
            saldo = rs.getDouble(1);
        }
    } catch (Exception ex) {
        Mensajes.MostrarTexto("ERROR al recuperar el stock: " + ex);
    }
    return saldo;
}
    
    public String dni(int id) {
    String dni = "";
    try {
        Connection con = Conexion.HacerConexion();
        PreparedStatement ps = con.prepareStatement(
            "SELECT dni FROM Tarjeta WHERE idtarjeta = ?;"
        );
        ps.setInt(1, id);
        ResultSet rs = ps.executeQuery();
        if (rs.next()) {
            dni = rs.getString(1);
        }
    } catch (Exception ex) {
        Mensajes.MostrarTexto("ERROR al recuperar la descripción: " + ex);
    }
    return dni;
}
    
    public String correo(int id) {
    String correo = "";
    try {
        Connection con = Conexion.HacerConexion();
        PreparedStatement ps = con.prepareStatement(
            "SELECT correo FROM Tarjeta WHERE idtarjeta = ?;"
        );
        ps.setInt(1, id);
        ResultSet rs = ps.executeQuery();
        if (rs.next()) {
            correo = rs.getString(1);
        }
    } catch (Exception ex) {
        Mensajes.MostrarTexto("ERROR al recuperar la descripción: " + ex);
    }
    return correo;
}
    
    public String celular(int id) {
    String celular = "";
    try {
        Connection con = Conexion.HacerConexion();
        PreparedStatement ps = con.prepareStatement(
            "SELECT celular FROM Tarjeta WHERE idtarjeta = ?;"
        );
        ps.setInt(1, id);
        ResultSet rs = ps.executeQuery();
        if (rs.next()) {
            celular = rs.getString(1);
        }
    } catch (Exception ex) {
        Mensajes.MostrarTexto("ERROR al recuperar la descripción: " + ex);
    }
    return celular;
}
    
    public byte[] imagen(int id) {
    byte[] imagen = null;
    try {
        Connection con = Conexion.HacerConexion();
        PreparedStatement ps = con.prepareStatement(
            "SELECT imagen FROM Tarjeta WHERE idtarjeta = ?;"
        );
        ps.setInt(1, id);
        ResultSet rs = ps.executeQuery();
        if (rs.next()) {
            imagen = rs.getBytes(1);
        }
    } catch (Exception ex) {
        Mensajes.MostrarTexto("ERROR al recuperar la descripción: " + ex);
    }
    return imagen;
}
    
    public Integer idTarjetaUsuario(int idUsuario) {
    Integer idTarjeta = null;
    try {
        Connection con = Conexion.HacerConexion();
        PreparedStatement ps = con.prepareStatement(
            "SELECT idtarjeta FROM Tarjeta WHERE id_usuario = ?;"
        );
        ps.setInt(1, idUsuario);
        ResultSet rs = ps.executeQuery();
        if (rs.next()) {
            idTarjeta = rs.getInt(1); // Recupera el idtarjeta
        }
    } catch (Exception ex) {
        Mensajes.MostrarTexto("ERROR al recuperar el idtarjeta: " + ex.getMessage());
    }
    return idTarjeta; // Devuelve el idtarjeta o null si no hay una tarjeta asociada
}
    public boolean ActualizarSaldo(int idTarjeta, double nuevoSaldo) {
    String consulta = "UPDATE tarjeta SET saldo = ? WHERE idtarjeta = ?";
    boolean actualizado = false;
    try {
        Connection con = Conexion.HacerConexion();
        PreparedStatement ps = con.prepareStatement(consulta);
        ps.setDouble(1, nuevoSaldo);
        ps.setInt(2, idTarjeta);
        int filasAfectadas = ps.executeUpdate();
        if (filasAfectadas > 0) {
            actualizado = true;
        }
    } catch (Exception ex) {
        Mensajes.MostrarTexto("Error al actualizar el saldo de la tarjeta: " + ex);
    }
    return actualizado;
}
    
    public Tarjeta BuscartarjetaId(int id) {
        Tarjeta tar=null;
        try{
            Connection con =  Conexion.HacerConexion();
            PreparedStatement ps = con.prepareStatement(
                          "select * from Tarjeta where idtarjeta = ?");
            ps.setInt(1, id);
            ResultSet rs=ps.executeQuery();
            if(rs.next()){
                tar = new Tarjeta();
                tar.setIdtarjeta(rs.getInt(1)); // idventa
                tar.setId_usuario(rs.getInt(2)); // nombre del cliente
                tar.setDni(rs.getString(3)); // total
                tar.setCorreo(rs.getString(4)); // fecha
                tar.setCelular(rs.getString(5)); // tipo de comprobante
                tar.setImagen(rs.getBytes(6)); // método de pago
                tar.setSaldo(rs.getDouble(7));
            }            
        }catch(Exception ex){
            Mensajes.MostrarTexto("ERROR no se puede recuperar"
                    + " Producto "+ex);
        }
        return tar;
    }
    
    
    

}
