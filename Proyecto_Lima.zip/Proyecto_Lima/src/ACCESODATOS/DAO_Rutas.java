package AccesoDatos;
import Configuracion.*;
import Interfaces.crudRutas;
import Procesos.Mensajes;
import ENTIDADES.Ruta;
import ENTIDADES.RutaFavorita;
import java.sql.*;
import java.util.ArrayList;
import javax.swing.JComboBox;
public class DAO_Rutas implements crudRutas {

    @Override
    public Ruta BuscarRutas(String Nombre_Ruta) {
        Ruta rut=null;
        try
        {
            Connection con =  Conexion.HacerConexion();
            PreparedStatement ps = con.prepareStatement(
                          "SELECT nomb_ruta, imagen" +
                          " FROM Rutas WHERE nomb_ruta =?");
            ps.setString(1,Nombre_Ruta);
            ResultSet rs=ps.executeQuery();
            if(rs.next()){
                rut = new Ruta();
                rut.setNom_ruta(rs.getString(1));
                rut.setImagen(rs.getBytes(2));
            }            
        }catch(Exception ex){
            Mensajes.MostrarTexto("ERROR no se puede recuperar"
                    + " Rutas "+ex);
        }
        return rut;
    }
    
    public Ruta BuscarRuta(String Nombre_Ruta) {
        Ruta rut=null;
        try
        {
            Connection con =  Conexion.HacerConexion();
            PreparedStatement ps = con.prepareStatement(
                          "SELECT imagen" +
                          " FROM Rutas WHERE nomb_ruta =?");
            ps.setString(1,Nombre_Ruta);
            ResultSet rs=ps.executeQuery();
            if(rs.next()){
                rut = new Ruta();
                rut.setImagen(rs.getBytes(1));
            }            
        }catch(Exception ex){
            Mensajes.MostrarTexto("ERROR no se puede recuperar"
                    + " Rutas "+ex);
        }
        return rut;
    }
    
    public int BuscarIDRuta(String Nombre_Ruta) {
        int id = 0;
        try
        {
            Connection con =  Conexion.HacerConexion();
            PreparedStatement ps = con.prepareStatement(
                          "SELECT id" +
                          " FROM Rutas WHERE nomb_ruta =?");
            ps.setString(1,Nombre_Ruta);
            ResultSet rs=ps.executeQuery();
            if(rs.next()){
                id = rs.getInt(1);
            }            
        }catch(Exception ex){
            Mensajes.MostrarTexto("ERROR no se puede recuperar"
                    + " Rutas "+ex);
        }
        return id;
    }
public void ActualizarComboRutas(JComboBox combo) {
        try{
            Connection con = Conexion.HacerConexion();
            PreparedStatement ps = con.prepareStatement("select nomb_ruta from rutas;");
            ResultSet rs = ps.executeQuery();
            while(rs.next()){
                combo.addItem(rs.getString(1));
            }
        }catch(Exception ex){
            Mensajes.MostrarTexto("ERROR no se puede cargar combo..."+ex);
        }
    }

public ArrayList<Ruta> ListarRuta() {
        String consulta = "SELECT id, nomb_ruta, lugar_de_salida, lugar_de_llegada, horario_disponible, días_disponibles" +
                          " FROM Rutas";
        ArrayList<Ruta> Lista = new ArrayList();
        try{
            Connection con = Conexion.HacerConexion();
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery(consulta);
            while(rs.next()){
                Ruta rt = new Ruta();
                rt.setId(rs.getInt(1));
                rt.setNom_ruta(rs.getString(2));
                rt.setLugar_de_salida(rs.getString(3));
                rt.setLugar_de_llegada(rs.getString(4));
                rt.setHorario_disponible(rs.getString(5));
                rt.setDías_disponibles(rs.getString(6));
                Lista.add(rt);
            }
        }catch(Exception ex){
            Mensajes.MostrarTexto("Error no se puede recuperar..."+ex);
        }
        return Lista;
    }

public ArrayList<Ruta> ListarRutasFavoritas(int idUsuario) {
    String consulta = "SELECT r.id, r.nomb_ruta, r.lugar_de_salida, r.lugar_de_llegada, " +
                       "r.horario_disponible, r.días_disponibles " +
                       "FROM rutas_favoritas rf " +
                       "INNER JOIN rutas r ON rf.id_ruta = r.id " +
                       "WHERE rf.id_usuario = ?";
    ArrayList<Ruta> listaFavoritas = new ArrayList<>();
    try {
        Connection con = Conexion.HacerConexion();
        PreparedStatement ps = con.prepareStatement(consulta);
        ps.setInt(1, idUsuario);
        ResultSet rs = ps.executeQuery();
        while (rs.next()) {
            Ruta rt = new Ruta();
            rt.setId(rs.getInt(1));
            rt.setNom_ruta(rs.getString(2));
            rt.setLugar_de_salida(rs.getString(3));
            rt.setLugar_de_llegada(rs.getString(4));
            rt.setHorario_disponible(rs.getString(5));
            rt.setDías_disponibles(rs.getString(6));
            listaFavoritas.add(rt);
        }
    } catch (Exception ex) {
        Mensajes.MostrarTexto("Error al recuperar las rutas favoritas: " + ex);
    }
    return listaFavoritas;
}

public void AgregarRutaFavoritas(RutaFavorita rf) {
        try{
            Connection con = Conexion.HacerConexion();
            PreparedStatement ps = con.prepareStatement("insert into rutas_favoritas(id_usuario,id_ruta,fecha_agregada) values(?,?,?);");
            ps.setInt(1, rf.getId_usuario());
            ps.setInt(2, rf.getId_ruta());
            ps.setString(3, rf.getFecha_agregada());
            ps.executeUpdate();
            Mensajes.MostrarTexto("Registro insertado correctamente...");
        }catch(Exception ex){
            Mensajes.MostrarTexto("Error no se puede insertar... "+ex);
        } 
    }

public boolean EsRutaFavorita(int idUsuario, int idRuta) {
    String consulta = "SELECT COUNT(*) FROM rutas_favoritas WHERE id_usuario = ? AND id_ruta = ?";
    boolean existe = false;
    try {
        Connection con = Conexion.HacerConexion();
        PreparedStatement ps = con.prepareStatement(consulta);
        ps.setInt(1, idUsuario);
        ps.setInt(2, idRuta);
        ResultSet rs = ps.executeQuery();
        if (rs.next()) {
            existe = rs.getInt(1) > 0; // Si el conteo es mayor a 0, la ruta ya está en favoritos.
        }
    } catch (Exception ex) {
        Mensajes.MostrarTexto("Error al verificar si la ruta ya es favorita: " + ex);
    }
    return existe;
}
}
