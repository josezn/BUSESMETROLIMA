
package ENTIDADES;

public class RutaFavorita {
    private int id;
    private int id_usuario;
    private int id_ruta;
    private String fecha_agregada;
    private String nomruta;
    
    public RutaFavorita(){}
    
    public Object[] Registro(int num){
        Object fila[] = {num,id_ruta,nomruta,fecha_agregada};
        return fila;
    }
    
    public int getId() {return id;}
    public void setId(int id) {this.id = id;}
    public int getId_usuario() {return id_usuario;}
    public void setId_usuario(int id_usuario) {this.id_usuario = id_usuario;}
    public int getId_ruta() {return id_ruta;}
    public void setId_ruta(int id_ruta) {this.id_ruta = id_ruta;}
    public String getFecha_agregada() {return fecha_agregada;}
    public void setFecha_agregada(String fecha_agregada) {this.fecha_agregada = fecha_agregada;}
    public String getNomruta() {return nomruta;}
    public void setNomruta(String nomruta) {this.nomruta = nomruta;}
    
    
}
