
package ENTIDADES;

public class MAPA {
    private double latitude;
    private double longitude;
    private int zoomLevel;
    private final String apiKey;

    public MAPA() {
        this.latitude = -12.0464;
        this.longitude = -77.0428;
        this.zoomLevel = 10; // Nivel de zoom inicial
        this.apiKey = "AIzaSyCgN3GUi68WHnLFQfObg5STohr72Ydw8p0"; // Coloca tu clave aquí
    }

    // Getters y setters
    public double getLatitude() {
        return latitude;
    }

    public void setLatitude(double latitude) {
        this.latitude = latitude;
    }

    public double getLongitude() {
        return longitude;
    }

    public void setLongitude(double longitude) {
        this.longitude = longitude;
    }

    public int getZoomLevel() {
        return zoomLevel;
    }

    public void setZoomLevel(int zoomLevel) {
        this.zoomLevel = zoomLevel;
    }

    public String getApiKey() {
        return apiKey;
    }
}
