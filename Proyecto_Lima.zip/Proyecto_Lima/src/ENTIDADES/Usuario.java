
package ENTIDADES;

public class Usuario {
    private Integer id;
    private String nomape;
    private String nomusuario;
    private String contraseña;
    private String correo;
    
    public Usuario(){}
    
    public Object[] Registro(int num){
        Object fila[] = {num,id,nomape,nomusuario,contraseña,correo};
        return fila;
    }

    public Integer getId() {return id; }
    public void setId(Integer id) {this.id = id; }
    public String getNomape() {return nomape;}
    public void setNomape(String nomape) {this.nomape = nomape;}
    public String getNomusuario() { return nomusuario;}
    public void setNomusuario(String nomusuario) {this.nomusuario = nomusuario;}
    public String getContraseña() {return contraseña; }
    public void setContraseña(String contraseña) {this.contraseña = contraseña;}
    public String getCorreo() {return correo;}
    public void setCorreo(String correo) {this.correo = correo;}  
    
}
