
package ENTIDADES;

public class Ruta {
    private int id;
    private String nom_ruta;
    private String lugar_de_salida;
    private String lugar_de_llegada;
    private String horario_disponible;
    private String días_disponibles;
    private byte[] imagen;
    
    public Ruta(){}
    
    public Object[] Registro(int num){
        Object fila[] = {num,id,nom_ruta,lugar_de_salida,lugar_de_llegada,horario_disponible,días_disponibles};
        return fila;
    }

    public int getId() {return id;}
    public void setId(int id) {this.id = id;}
    public String getNom_ruta() {return nom_ruta;}
    public void setNom_ruta(String nom_ruta) {this.nom_ruta = nom_ruta;}
    public String getLugar_de_salida() {return lugar_de_salida;}
    public void setLugar_de_salida(String lugar_de_salida) {this.lugar_de_salida = lugar_de_salida;}
    public String getLugar_de_llegada() {return lugar_de_llegada;}
    public void setLugar_de_llegada(String lugar_de_llegada) { this.lugar_de_llegada = lugar_de_llegada;}
    public String getHorario_disponible() {return horario_disponible;}
    public void setHorario_disponible(String horario_disponible) {this.horario_disponible = horario_disponible;}
    public String getDías_disponibles() {return días_disponibles;}
    public void setDías_disponibles(String días_disponibles) {this.días_disponibles = días_disponibles;}
    public byte[] getImagen() {return imagen; }
    public void setImagen(byte[] imagen) {this.imagen = imagen;}
    
    
}
