
package ENTIDADES;

public class Tarjeta {
    private int idtarjeta;
    private int id_usuario;
    private String dni;
    private String correo;
    private String celular;
    private byte[] imagen;
    private double saldo;

    public int getIdtarjeta() {return idtarjeta;}
    public void setIdtarjeta(int idtarjeta) {this.idtarjeta = idtarjeta;}
    public int getId_usuario() {return id_usuario;}
    public void setId_usuario(int id_usuario) {this.id_usuario = id_usuario;}
    public String getDni() {return dni;}
    public void setDni(String dni) {this.dni = dni;}
    public String getCelular() {return celular;}
    public void setCelular(String celular) {this.celular = celular;}
    public String getCorreo() {return correo; }
    public void setCorreo(String correo) {this.correo = correo;}
    public byte[] getImagen() {return imagen;}
    public void setImagen(byte[] imagen) {this.imagen = imagen;}
    public double getSaldo() {return saldo;}
    public void setSaldo(double saldo) {this.saldo = saldo;}
}
