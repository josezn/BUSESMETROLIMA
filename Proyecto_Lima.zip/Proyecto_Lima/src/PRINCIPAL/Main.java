package Principal;

import Controladores.ControladorLogin;
import FORMULARIOS.FrmInicioSesion;

public class Main {
    public static void main(String[] args) {
        ControladorLogin cin = new ControladorLogin(new FrmInicioSesion());
        
    }
    
}
