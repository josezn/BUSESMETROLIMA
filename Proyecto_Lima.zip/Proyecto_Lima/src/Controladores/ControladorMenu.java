package Controladores;
import AccesoDatos.DAO_Rutas;
import ENTIDADES.Usuario;
import ENTIDADES.MAPA;
import ENTIDADES.Ruta;
import FORMULARIOS.FrmMenuPrincipal;
import FORMULARIOS.FrmMenuTarjetaVirtual;
import FORMULARIOS.FrmRutasGenerales;
import FORMULARIOS.FrmFavoritos;
import FORMULARIOS.FrmBusqueda;
import FORMULARIOS.FrmInicioSesion;
import FORMULARIOS.FrmMaps;
import Procesos.Mensajes;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;

public class ControladorMenu implements ActionListener {
         FrmMenuPrincipal vistas;
         Usuario usuario;
    
         public ControladorMenu (FrmMenuPrincipal mep,Usuario usuario){
             vistas = mep;
             this.usuario = usuario;
             vistas.jbtnBuscar.addActionListener(this);
             vistas.jbtnFavoritas.addActionListener(this);
             vistas.jbtnMapa.addActionListener(this);
             vistas.jbtnRutas.addActionListener(this);
             vistas.jbtnTarjeta.addActionListener(this);
             vistas.jbtnCerrar.addActionListener(this);
         }
    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource()==vistas.jbtnBuscar){
            if(vistas.jtxtBuscarRuta.getText().trim().isEmpty()){
                Mensajes.MostrarTexto("Colocar ruta");
                return;
            }
            String nombreRuta = vistas.jtxtBuscarRuta.getText();
            DAO_Rutas dao = new DAO_Rutas();
            Ruta ruta = dao.BuscarRutas(nombreRuta);
            if (ruta != null) {
            FrmBusqueda fm = new FrmBusqueda();
            ControladorRutaBuscada controladorRuta = new ControladorRutaBuscada(fm, nombreRuta,usuario);
            fm.setTitle("Ruta encontrada...");
            fm.setVisible(true);
            vistas.dispose();
        }else if(ruta == null){
            Mensajes.MostrarTexto("La ruta no existe");
        }
        }else if(e.getSource()==vistas.jbtnFavoritas) {
            FrmFavoritos fm = new FrmFavoritos();
            fm.setTitle("Menu......");
            ControladorRutaFavoritas cm = new ControladorRutaFavoritas(fm,usuario);
            fm.setVisible(true);
            vistas.dispose();
        }else if(e.getSource()==vistas.jbtnMapa){
            FrmMaps fm = new FrmMaps();
            MAPA mapa = new MAPA();  // Crear el modelo del mapa
            ControladorMapa controladorMapa = new ControladorMapa(mapa, fm,usuario);  // Crear el controlador
            fm.setVisible(true);
            vistas.dispose();
        }else if(e.getSource()==vistas.jbtnRutas){
            FrmRutasGenerales fm = new FrmRutasGenerales();
            fm.setTitle("Rutas......");
            ControladorRutas cm = new ControladorRutas(fm,usuario);
            fm.setVisible(true);
            vistas.dispose();
        }else if(e.getSource()==vistas.jbtnTarjeta){
            if (usuario.getId() == -1) {
            Mensajes.MostrarTexto("Esta función no está disponible para usuarios invitados.");
            return;
            }else{
            FrmMenuTarjetaVirtual fm = new FrmMenuTarjetaVirtual();
            fm.setTitle("Menu Tarjeta......");
            ControladorMenuTarjeta cm = new ControladorMenuTarjeta(fm,usuario);
            fm.setVisible(true);
            vistas.dispose();
            }
        }else if(e.getSource()==vistas.jbtnCerrar){
            FrmInicioSesion fi = new FrmInicioSesion();
            ControladorLogin cl = new ControladorLogin(fi);
            fi.setVisible(true);
            vistas.dispose();
        }
    }
    
}
