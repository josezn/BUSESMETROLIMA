
package Controladores;
import ENTIDADES.Usuario;
import FORMULARIOS.FrmMiTarjeta;
import FORMULARIOS.FrmMenuTarjetaVirtual;
import ACCESODATOS.DAO_Tarjeta;
import FORMULARIOS.FrmMenuPrincipal;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
public class ControladorMiTarjetaVirtual implements ActionListener{
    
    FrmMiTarjeta vista;
    Usuario usuario;
    
    public ControladorMiTarjetaVirtual(FrmMiTarjeta in,Usuario usuario){
         vista=in;
         this.usuario = usuario;
         MiTarjeta();
         vista.jbtnMenu.addActionListener(this);

    }
    
    private void MiTarjeta(){
        if (usuario != null) {
            DAO_Tarjeta dao = new DAO_Tarjeta();
            int id_tarjeta = dao.idTarjeta(usuario.getId());
            double saldo = dao.saldoTarjeta(id_tarjeta);
                 vista.jlblNombresApellidos.setText(usuario.getNomape());
                 vista.jlbldni.setText(dao.dni(id_tarjeta));
                 vista.jlblcorreo.setText(dao.correo(id_tarjeta));
                 vista.jlblCelular.setText(dao.celular(id_tarjeta));
                 vista.jlblcodigo.setText(String.valueOf(id_tarjeta));
                 byte[] imagen = dao.imagen(id_tarjeta);
                 vista.jlblcodigo.setText(String.valueOf(id_tarjeta));
                 vista.jlblSaldo.setText(String.valueOf(saldo));
                 if (imagen != null) {
                     ImageIcon icon = new ImageIcon(imagen);
                     Image img = icon.getImage().getScaledInstance(
                     vista.jlblimagen.getWidth(),
                     vista.jlblimagen.getHeight(),
                     Image.SCALE_SMOOTH);
                     vista.jlblimagen.setIcon(new ImageIcon(img));
                     vista.jlblimagen.setText("");
                     
                    
                     
                 }else{
                     vista.jlblimagen.setIcon(null);
                     vista.jlblimagen.setText("No hay imagen");
                 }
             }else{
                 JOptionPane.showMessageDialog(vista, "Producto no encontrado.");
             }
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource()==vista.jbtnMenu){
            FrmMenuPrincipal fm = new FrmMenuPrincipal();
            fm.setTitle("Menu......");
            ControladorMenu cm = new ControladorMenu(fm,usuario);
            fm.setVisible(true);
            vista.dispose();
        }
    }
}
