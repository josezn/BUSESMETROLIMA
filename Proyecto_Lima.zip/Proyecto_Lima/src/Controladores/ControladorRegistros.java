package Controladores;

import AccesoDatos.DAO_Usuario;
import Procesos.ProcesoUsuario;
import Procesos.Mensajes;
import FORMULARIOS.FrmRegistrar;
import FORMULARIOS.FrmInicioSesion;
import ENTIDADES.Usuario;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ControladorRegistros implements ActionListener {
       FrmRegistrar  vista;
    
    public ControladorRegistros (FrmRegistrar reg){
        vista = reg;
        vista.jbtnRegistrarme.addActionListener(this); 
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource()==vista.jbtnRegistrarme){
           if (!vista.jchbxaceptar.isSelected()) {
            Mensajes.MostrarTexto("Debe aceptar los términos y condiciones para continuar.");
            return;
        }
        Usuario us = ProcesoUsuario.LeerUsuario(vista);
        DAO_Usuario dao = new DAO_Usuario();
        dao.AgregarUs(us);
        Mensajes.MostrarTexto("Registro exitoso");
        FrmInicioSesion fm = new FrmInicioSesion();
        ControladorLogin lo = new ControladorLogin(fm);
        fm.setVisible(true);
        vista.dispose();
        }
    }
}
