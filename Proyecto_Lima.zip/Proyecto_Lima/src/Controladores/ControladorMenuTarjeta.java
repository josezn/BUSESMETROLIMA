
package Controladores;
import ACCESODATOS.DAO_Tarjeta;
import ENTIDADES.Usuario;
import FORMULARIOS.FrmCrearTarjeta;
import FORMULARIOS.FrmMenuPrincipal;
import FORMULARIOS.FrmMiTarjeta;
import FORMULARIOS.FrmRecargarTarjeta;
import FORMULARIOS.FrmMenuTarjetaVirtual;
import Procesos.Mensajes;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ControladorMenuTarjeta implements ActionListener{
    FrmMenuTarjetaVirtual vista;
    Usuario usuario;
    
    public ControladorMenuTarjeta(FrmMenuTarjetaVirtual in,Usuario usuario){
         vista=in;
         this.usuario = usuario;
         vista.jbtnCrear.addActionListener(this);
         vista.jbtnMiTarjeta.addActionListener(this);
         vista.jbtnRecargar.addActionListener(this);
         vista.jbtnRegresar.addActionListener(this);
     }
    
    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource()==vista.jbtnCrear){
            DAO_Tarjeta dao = new DAO_Tarjeta();
            Integer idtarjeta = dao.idTarjetaUsuario(usuario.getId());
            if (idtarjeta == null) {
                FrmCrearTarjeta fm = new FrmCrearTarjeta();
                fm.setTitle("Mi Tarjeta");
                ControladorCrearTarjeta cm = new ControladorCrearTarjeta(fm,usuario);
                fm.setVisible(true);
                vista.dispose();
            }else {
                Mensajes.MostrarTexto("Ya cuentas con una tarjeta virtual");
            }         
        }else if(e.getSource()==vista.jbtnMiTarjeta) {
            DAO_Tarjeta dao = new DAO_Tarjeta();
            Integer idtarjeta = dao.idTarjetaUsuario(usuario.getId());
            if(usuario == null){
                Mensajes.MostrarTexto("Tienes que crear una tarjeta virtual");
            }else if(usuario != null && idtarjeta != null){
                FrmMiTarjeta fm = new FrmMiTarjeta();
                fm.setTitle("Mi Tarjeta......");
                ControladorMiTarjetaVirtual cm = new ControladorMiTarjetaVirtual(fm,usuario);
                fm.setVisible(true);
                vista.dispose();
                               
            }else{
                Mensajes.MostrarTexto("Necesitas crear una tarjeta virtual");
            }   
        }else if(e.getSource()==vista.jbtnRecargar){
            DAO_Tarjeta dao = new DAO_Tarjeta();
            Integer idtarjeta = dao.idTarjetaUsuario(usuario.getId());
            if(usuario == null){
                Mensajes.MostrarTexto("Tienes que crear una tarjeta virtual");
            }else if(usuario != null && idtarjeta != null){
             FrmRecargarTarjeta fm = new FrmRecargarTarjeta();
            fm.setTitle("Recargar saldo......");
            ControladorRecarga cm = new ControladorRecarga(fm,usuario);
            fm.setVisible(true);
            vista.dispose();
            }else{
                Mensajes.MostrarTexto("Necesitas crear una tarjeta virtual");
            }   
        }else if(e.getSource()==vista.jbtnRegresar){
            FrmMenuPrincipal fm = new FrmMenuPrincipal();
               fm.setTitle("Menu......");
               ControladorMenu cm = new ControladorMenu(fm,usuario);
               fm.setVisible(true);
               vista.dispose();
        }
    }
    
}
