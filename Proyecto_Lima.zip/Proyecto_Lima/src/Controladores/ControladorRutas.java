package Controladores;
import ENTIDADES.Ruta;
import AccesoDatos.DAO_Rutas;
import FORMULARIOS.FrmRutasGenerales;
import FORMULARIOS.FrmMenuPrincipal;
import Procesos.ProcesoRutas;
import java.awt.Image;
import ENTIDADES.Usuario;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;


public class ControladorRutas implements ActionListener {

    FrmRutasGenerales vista;
    Usuario usuario;
    
    public ControladorRutas(FrmRutasGenerales cr,Usuario usuario){
        vista = cr;
        this.usuario = usuario;
        vista.jbtnVerRuta.addActionListener(this); 
        vista.jbtnRegresar.addActionListener(this); 
        ActualizarTabla();
    }
    
    void ActualizarTabla(){
        DAO_Rutas dao = new DAO_Rutas();
        ProcesoRutas.MostrarEnTablaRutas(vista, dao.ListarRuta());
        
    }
    private void cargarDatosRuta(String nombreRuta) {
        DAO_Rutas dao = new DAO_Rutas();
        Ruta ruta = dao.BuscarRuta(nombreRuta); // Busca la ruta por nombre

        if (ruta != null) {
            System.out.println("Datos de la ruta encontrados."); 

            byte[] imgBytes = ruta.getImagen();
            if (imgBytes != null) {
                ImageIcon icon = new ImageIcon(imgBytes);
                vista.jlblruta.setIcon(new ImageIcon(
                    icon.getImage().getScaledInstance(
                        vista.jlblruta.getWidth(),
                        vista.jlblruta.getHeight(),
                        Image.SCALE_SMOOTH
                    )
                ));
            } else {
                System.out.println("La ruta no tiene una imagen asociada.");
                JOptionPane.showMessageDialog(vista, "No se encontró imagen para la ruta.");
            }
        } else {
            System.out.println("La ruta no fue encontrada o hubo un error.");
            JOptionPane.showMessageDialog(vista, "No se encontró la ruta especificada.");
        }
    }
   

    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource()== vista.jbtnVerRuta){
            int row = vista.jtblrutasgenerales.getSelectedRow();
            String ruta = vista.jtblrutasgenerales.getValueAt(row, 2).toString();
            cargarDatosRuta(ruta);
            
         }else if(e.getSource()== vista.jbtnRegresar){
            FrmMenuPrincipal fm = new FrmMenuPrincipal();
            fm.setTitle("Menu......");
            ControladorMenu cm = new ControladorMenu(fm,usuario);
            fm.setVisible(true);
            vista.dispose();
         }
        }
    }


    

