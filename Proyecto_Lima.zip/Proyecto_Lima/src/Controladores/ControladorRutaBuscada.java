
package Controladores;
import FORMULARIOS.FrmBusqueda;
import FORMULARIOS.FrmMenuPrincipal;
import AccesoDatos.DAO_Rutas;
import ENTIDADES.Ruta;
import ENTIDADES.RutaFavorita;
import ENTIDADES.Usuario;
import Procesos.Mensajes;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;

public class ControladorRutaBuscada implements ActionListener{
    
    FrmBusqueda vistas;
    String nombreRuta;
    Usuario usuario;
    
         public ControladorRutaBuscada (FrmBusqueda mep, String nombreRuta, Usuario usuario){
             vistas = mep;
             this.usuario = usuario;
             this.nombreRuta = nombreRuta;
             vistas.jbtnAtras.addActionListener(this);
             vistas.jtbnGuardar.addActionListener(this);
             cargarDatosRuta();
         }
         
         private void cargarDatosRuta() {
        DAO_Rutas dao = new DAO_Rutas();
    Ruta ruta = dao.BuscarRutas(nombreRuta); // Busca la ruta por nombre

    if (ruta != null) {
        System.out.println("Datos de la ruta encontrados.");
        vistas.jlblnom.setText(ruta.getNom_ruta());

        byte[] imgBytes = ruta.getImagen();
        if (imgBytes != null) {
            ImageIcon icon = new ImageIcon(imgBytes);
            vistas.jlblImagenRuta.setIcon(new ImageIcon(
                icon.getImage().getScaledInstance(
                    vistas.jlblImagenRuta.getWidth(),
                    vistas.jlblImagenRuta.getHeight(),
                    Image.SCALE_SMOOTH
                )
            ));
        } else {
            System.out.println("La ruta no tiene una imagen asociada.");
            JOptionPane.showMessageDialog(vistas, "No se encontró imagen para la ruta.");
        }
    } else {
        System.out.println("La ruta no fue encontrada o hubo un error.");
        JOptionPane.showMessageDialog(vistas, "No se encontró la ruta especificada.");
    }
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource()==vistas.jbtnAtras){
            FrmMenuPrincipal fm = new FrmMenuPrincipal();
            fm.setTitle("Menu......");
            ControladorMenu cm = new ControladorMenu(fm,usuario);
            fm.setVisible(true);
            vistas.dispose();
        }else if(e.getSource()==vistas.jtbnGuardar){
            if (usuario.getId() == -1) {
            Mensajes.MostrarTexto("Esta función no está disponible para usuarios invitados.");
            return;
            }
            DAO_Rutas dao = new DAO_Rutas();
            int id_ruta = dao.BuscarIDRuta(nombreRuta);
            if(dao.EsRutaFavorita(usuario.getId(), id_ruta) == true){
                vistas.jtbnGuardar.setEnabled(false);
                Mensajes.MostrarTexto("La ruta ya ha sido guardada");
            }else{
            RutaFavorita rf =  new RutaFavorita();
            String fecha = new SimpleDateFormat("yyyy-MM-dd").format(new Date());
            rf.setId_usuario(usuario.getId());
            rf.setId_ruta(id_ruta);
            rf.setNomruta(fecha);
            dao.AgregarRutaFavoritas(rf);
            }
        }
    }
    
}
