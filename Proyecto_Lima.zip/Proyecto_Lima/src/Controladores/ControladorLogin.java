package Controladores;

import AccesoDatos.DAO_Usuario;
import Procesos.Mensajes;
import Procesos.ProcesoIniciarSesion;
import FORMULARIOS.FrmInicioSesion;
import ENTIDADES.Usuario;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import FORMULARIOS.FrmMenuPrincipal;
import FORMULARIOS.FrmRegistrar;

public class ControladorLogin implements ActionListener{
    
    FrmInicioSesion vista;
    
    public ControladorLogin(FrmInicioSesion in){
         vista=in;
         vista.jbtnIniciar.addActionListener(this);
         vista.jbtnRegistrar.addActionListener(this);
         vista.jbtnInicioInvitado.addActionListener(this);
         ProcesoIniciarSesion.Presentacion(in);
     }
    
    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource()==vista.jbtnIniciar){
           Usuario usuario = ProcesoIniciarSesion.LeerUsuario(vista);
           usuario = DAO_Usuario.VerificarUsuario(usuario);
           if(usuario==null){
               Mensajes.MostrarTexto("Las credenciales son incorrectas");
           }else{
               FrmMenuPrincipal fm = new FrmMenuPrincipal();
               fm.setTitle("Menu......");
               ControladorMenu cm = new ControladorMenu(fm,usuario);
               fm.setVisible(true);
               vista.dispose();
           }
        }else if(e.getSource()==vista.jbtnInicioInvitado) {
               Usuario invitado = new Usuario();
               invitado.setId(-1); // ID especial para invitados
               invitado.setNomusuario("Invitado");
               FrmMenuPrincipal fm = new FrmMenuPrincipal();
               fm.setTitle("Menú Principal - Invitado");
               ControladorMenu cm = new ControladorMenu(fm, invitado);
               fm.setVisible(true);
               vista.dispose();
        }else if(e.getSource()==vista.jbtnRegistrar){
               FrmRegistrar fm = new FrmRegistrar();
               ControladorRegistros reg = new ControladorRegistros(fm);
               fm.setVisible(true);
               vista.dispose();
        }
    }
    
}
