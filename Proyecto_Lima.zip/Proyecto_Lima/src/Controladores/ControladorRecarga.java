
package Controladores;

import ACCESODATOS.DAO_Tarjeta;
import ENTIDADES.Tarjeta;
import ENTIDADES.Usuario;
import FORMULARIOS.FrmMenuPrincipal;
import FORMULARIOS.FrmMenuTarjetaVirtual;
import FORMULARIOS.FrmRecargarTarjeta;
import Procesos.Mensajes;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ControladorRecarga implements ActionListener{
    
    FrmRecargarTarjeta vista;
    Usuario usuario;
    
    public ControladorRecarga(FrmRecargarTarjeta in,Usuario usuario){
         vista=in;
         this.usuario = usuario;
         vista.jbtnRecargar.addActionListener(this);
         vista.jbtnMenu.addActionListener(this);
         MiSaldo();
     }
    
    private void MiSaldo(){
        if (usuario != null) {
            DAO_Tarjeta dao = new DAO_Tarjeta();
            int id_tarjeta = dao.idTarjeta(usuario.getId());
            double saldo = dao.saldoTarjeta(id_tarjeta);
            vista.jlblSaldoActual.setText(String.valueOf(saldo));
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource()==vista.jbtnRecargar){
            if (vista.jtxtMontoRecarga.getText().isEmpty()) {
                Mensajes.MostrarTexto("Por favor, añade un monto antes de continuar.");
                return; // Detener el proceso si no hay productos en el carrito
            }
            if (vista.jtbnYape.isSelected() && vista.jtbmTarjeta.isSelected()) {
                Mensajes.MostrarTexto("Solo debes seleccionar uno: Yape o Tarjeta.");
                return; // No continuar si ambos están seleccionados
            } else if (!vista.jtbnYape.isSelected() && !vista.jtbmTarjeta.isSelected()) {
                Mensajes.MostrarTexto("Debes seleccionar uno: Yape o Tarjeta.");
                return; // No continuar si ninguno está seleccionado
            }
            
            double monto = Double.parseDouble(vista.jtxtMontoRecarga.getText());
            DAO_Tarjeta dao = new DAO_Tarjeta();
            int id_tarjeta = dao.idTarjeta(usuario.getId());
            dao.ActualizarSaldo(id_tarjeta, monto);
            Mensajes.MostrarTexto("Se realizo la recarga");
            FrmMenuTarjetaVirtual fm = new FrmMenuTarjetaVirtual();
            fm.setTitle("Menu Tarjeta......");
            ControladorMenuTarjeta cm = new ControladorMenuTarjeta(fm,usuario);
            fm.setVisible(true);
            vista.dispose();
        }else if(e.getSource()==vista.jbtnMenu){
            FrmMenuPrincipal fm = new FrmMenuPrincipal();
               fm.setTitle("Menu......");
               ControladorMenu cm = new ControladorMenu(fm,usuario);
               fm.setVisible(true);
               vista.dispose();
        }
    }
    
}
