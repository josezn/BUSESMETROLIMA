
package Controladores;

import AccesoDatos.DAO_Rutas;
import ENTIDADES.Usuario;
import FORMULARIOS.FrmFavoritos;
import FORMULARIOS.FrmMenuPrincipal;
import Procesos.ProcesoRutas;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ControladorRutaFavoritas implements ActionListener{
    
    FrmFavoritos vista;
    Usuario usuario;
    
    public ControladorRutaFavoritas(FrmFavoritos cr,Usuario usuario){
        vista = cr;
        this.usuario = usuario;
        vista.jbtnRegresar.addActionListener(this); 
        ActualizarTabla();
    }
    
    void ActualizarTabla(){
        DAO_Rutas dao = new DAO_Rutas();
        ProcesoRutas.MostrarEnTablaRutasFvaoritas(vista, dao.ListarRutasFavoritas(usuario.getId()));
        
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource()== vista.jbtnRegresar){
            FrmMenuPrincipal fm = new FrmMenuPrincipal();
            fm.setTitle("Menu......");
            ControladorMenu cm = new ControladorMenu(fm,usuario);
            fm.setVisible(true);
            vista.dispose();
         }
    }
    
}
