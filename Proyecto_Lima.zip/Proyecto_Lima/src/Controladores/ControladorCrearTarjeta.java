
package Controladores;
import ENTIDADES.Tarjeta;
import FORMULARIOS.FrmCrearTarjeta;
import FORMULARIOS.FrmMenuTarjetaVirtual;
import ACCESODATOS.DAO_Tarjeta;
import ENTIDADES.Usuario;
import PROCESOS.ProcesoTarjeta;
import Procesos.Mensajes;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
public class ControladorCrearTarjeta implements ActionListener{
    
    FrmCrearTarjeta vista;
    Usuario usuario;
    String rutaImagen;
    Runnable actualizarLabels;
    
    public ControladorCrearTarjeta(FrmCrearTarjeta frp,Usuario usuario){
        vista = frp;
        this.usuario = usuario;
        vista.jbtnCrear.addActionListener(this); 
        vista.jbtnCargar.addActionListener(this); 
        vista.jbtnMenu.addActionListener(this); 
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource()==vista.jbtnCrear){
            if(validarCamposRellenados()){
           if (!vista.jchbxAceptar.isSelected()) {
            Mensajes.MostrarTexto("Debe aceptar los términos y condiciones para continuar.");
            return;
           }
           Tarjeta pr =  ProcesoTarjeta.LeerTarjeta(vista,rutaImagen);
           DAO_Tarjeta dao =  new DAO_Tarjeta();
           dao.AgregarTar(pr);
            }
        }else if(e.getSource()==vista.jbtnCargar){
            JFileChooser fileChooser = new JFileChooser();
            fileChooser.setFileSelectionMode(JFileChooser.FILES_ONLY);
            int result = fileChooser.showOpenDialog(vista);
            if (result == JFileChooser.APPROVE_OPTION) {
                File file = fileChooser.getSelectedFile();
                ImageIcon icon = new ImageIcon(file.getPath());
                Image img = icon.getImage().getScaledInstance(
                vista.jlblFoto.getWidth(), 
                vista.jlblFoto.getHeight(), 
                Image.SCALE_SMOOTH);
                vista.jlblFoto.setIcon(new ImageIcon(img));
                vista.jlblFoto.setText(""); // Quitar texto de etiqueta
                rutaImagen = file.getPath();
            }
        }else if(e.getSource()==vista.jbtnMenu){
            FrmMenuTarjetaVirtual fv = new FrmMenuTarjetaVirtual();
            ControladorMenuTarjeta cmt = new ControladorMenuTarjeta(fv,usuario);
            fv.setVisible(true);
            vista.dispose();
        }
    }
    
    private boolean validarCamposRellenados() {
        if (vista.jtxtNombres.getText().trim().isEmpty() ||
               vista.jtxtApellidos.getText().trim().isEmpty() ||
               vista.jtxtDni.getText().trim().isEmpty() ||
               vista.jtxtCorreo.getText().trim().isEmpty() ||
                vista.jtxtCelular.getText().trim().isEmpty()){
               Mensajes.MostrarTexto( "Todos los campos deben estar llenos.");
               return false;
        }


        if(vista.jlblFoto.getIcon() == null){
            Mensajes.MostrarTexto( "Todos los campos deben estar llenos.");
            return false;
        }

        return true;
    }
    
}
