
package Controladores;
import FORMULARIOS.FrmMaps;
import ENTIDADES.MAPA;
import ENTIDADES.Usuario;
import FORMULARIOS.FrmMenuPrincipal;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import org.jxmapviewer.viewer.GeoPosition;
public class ControladorMapa {
    FrmMaps vista;
    MAPA mapa;
    Usuario usuario;

    public ControladorMapa(MAPA mapa, FrmMaps vista,Usuario usuario) {
        this.mapa = mapa;
        this.vista = vista;
        this.usuario = usuario;

        // Enlazar los eventos de los botones de zoom y movimiento
        this.vista.addZoomInListener(new ZoomInListener());
        this.vista.addZoomOutListener(new ZoomOutListener());
        this.vista.addMoveLeftListener(new MoveLeftListener());
        this.vista.addMoveRightListener(new MoveRightListener());
        this.vista.addMoveUpListener(new MoveUpListener());
        this.vista.addMoveDownListener(new MoveDownListener());
        this.vista.addMenu(new Menu());
    }

    // Clase interna para manejar el zoom in
    class ZoomInListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            if (mapa.getZoomLevel() < 18) { // Limitar el zoom máximo
                mapa.setZoomLevel(mapa.getZoomLevel() + 1);
                updateView();
            }
        }
    }

    // Clase interna para manejar el zoom out
    class ZoomOutListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            if (mapa.getZoomLevel() > 1) { // Limitar el zoom mínimo
                mapa.setZoomLevel(mapa.getZoomLevel() - 1);
                updateView();
            }
        }
    }

    // Clase interna para mover el mapa a la izquierda
    class MoveLeftListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            mapa.setLongitude(mapa.getLongitude() - 0.01);  // Ajustar el valor de desplazamiento
            updateView();
        }
    }

    // Clase interna para mover el mapa a la derecha
    class MoveRightListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            mapa.setLongitude(mapa.getLongitude() + 0.01);  // Ajustar el valor de desplazamiento
            updateView();
        }
    }

    // Clase interna para mover el mapa hacia arriba
    class MoveUpListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            mapa.setLatitude(mapa.getLatitude() + 0.01);  // Ajustar el valor de desplazamiento
            updateView();
        }
    }

    // Clase interna para mover el mapa hacia abajo
    class MoveDownListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            mapa.setLatitude(mapa.getLatitude() - 0.01);  // Ajustar el valor de desplazamiento
            updateView();
        }
    }
    
    class Menu implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            FrmMenuPrincipal fm = new FrmMenuPrincipal();
            fm.setTitle("Menu......");
            ControladorMenu cm = new ControladorMenu(fm,usuario);
            fm.setVisible(true);
            vista.dispose();
        }
    }

    // Actualizar la vista con la nueva ubicación y nivel de zoom
    private void updateView() {
        GeoPosition position = new GeoPosition(mapa.getLatitude(), mapa.getLongitude());
        vista.setPosition(position, mapa.getZoomLevel());
    }
    
    
}
