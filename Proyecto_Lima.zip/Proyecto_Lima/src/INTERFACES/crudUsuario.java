package Interfaces;
import ENTIDADES.Usuario;
public interface crudUsuario {
       public void AgregarUs(Usuario us);      
    }
