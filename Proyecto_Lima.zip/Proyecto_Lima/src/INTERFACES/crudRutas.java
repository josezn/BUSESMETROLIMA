package Interfaces;
import ENTIDADES.Ruta;
public interface crudRutas {
     public Ruta BuscarRutas(String Nombre_Ruta);   
}
