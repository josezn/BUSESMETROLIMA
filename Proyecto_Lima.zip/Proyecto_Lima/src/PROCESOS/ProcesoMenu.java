
package Procesos;

import FORMULARIOS.FrmMenuPrincipal;

public class ProcesoMenu {
   
     public static void Presentacion(FrmMenuPrincipal mp){
        mp.setTitle("Registro de Clientes");
    
}
}
