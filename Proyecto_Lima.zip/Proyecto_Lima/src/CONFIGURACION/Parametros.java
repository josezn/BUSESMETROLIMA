
package Configuracion;

public interface Parametros {
    String DRIVER="com.mysql.cj.jdbc.Driver";
    String URL="jdbc:mysql://localhost:3309/Sistemadebuses";
    String USER="root";
    String CLAVE="";   
}
